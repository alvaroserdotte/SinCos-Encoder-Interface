/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define ARM_MATH_CM4
#include "arm_math.h"
//#include "rt_fp.h"
#include "fonts.h"
#include "ssd1306.h"
//#include "test.h"
//#include "bitmap.h"
//#include "stdio.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
ADC_HandleTypeDef hadc4;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc3;

I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_ADC2_Init(void);
static void MX_ADC3_Init(void);
static void MX_ADC4_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */
void INIT_ALL(void);
void Atan_interp(void);
void Enc_Process_INIT(void);
void Enc_Process_Fine(void);
void Enc_Process_Coarse(void);
//void ENC_Tracking_Process();
void PMSM_FOC(void);
void Trip(void);
void Table_char_PC(void);
int MAX(int v1,int v2,int v3);
int MIN(int v1,int v2,int v3);
//int ADC_SYNC();
int SSR_RELAY;
float tqtemp;
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//extern long int TIM_RPM;
//extern float RPMf,RPMf2;
//float RPMMM;
extern volatile float Chiptemp;
int ADC_ENC_SYNC;
extern int POT_TQ,POT_RPM;
float delayTQ = 0.0f;
const int delay_1 = 1100;		//OFFSET IU e IV
const int delay_2 = 4000;		//Alignment + Module Break Fault enable
const int delay_3 = 18000;		//Alignment
volatile float ABS_Position;
volatile int Encoder_CNT;
uint8_t check;
const float SQRT13 =  0.5773502f;   //	1/sqrt(3)
const float SQRT23 =  1.1547005f;   //	2/sqrt(3)
const float SQRT32 = 	0.8660254f;  	//	sqrt(3)/2
const int SQRT32_INT = 28377;
const int SQRT13_INT = 18918;
const int SQRT23_INT = 37836;
const float PIRAD = 3.1415926f;
const float PIRAD_2 = 1.57079f;
int oi = 0;

char buf[5];
char buf2[20];
uint8_t TABLETXPC[50];

//ENCODER CONFIG
//const uint16_t ENC_PULSES = 8000;
//const uint16_t ENC_INITIAL = ENC_PULSES/2 - 1;
//const float ENC_PULSES_TO_DEGREES = 360.0f/ENC_PULSES;


uint16_t ANG,ANG_OFFSET;

//MOTOR CONFIG
const uint16_t MOTOR_POLES = 4;

//REDUCER GEAR
const float GEAR_RATIO = 1.0f/30.0f;
typedef union {
		float f;
		unsigned char c[4];
}FloatU;
int ix;
typedef struct {
	int P;
	int I;
	int D;
	int P2;
	int SetPoint;
} Control_Parameter;
extern float IUF,IVF,VFBK2,TempSTK; 

int I_PROT_COUNT = 15, Protect_I_Count = 0;
int I_PROTECTION = 10*83;//500;
float I_NOMINAL = (float)83*8;

extern int IU_OFFSET,IV_OFFSET;
float IUCALIB,IVCALIB,Data_Position,DataT;
float SP_q,SP_d;
volatile char Status = 0;
int Pos_int;
int POT = 0,POTD = 0;
float IQM;
uint16_t Pos_uint;

int delay;
volatile short int Pos_degrees,Pos_elec,Pos_Sin,Pos_Cos;
volatile short int SENO,SENO2;
extern int RPM;
uint16_t merda;

//teste
int Q_;
int RMS,ADC_Q_1,ADC_Q_2;


//float Pos_e;
Control_Parameter CSpd,CCur;
int Va,Vb,Vc;
int Va2,Vb2,Vc2,Vm2,VaMAX;
//float ialfa,ibeta;
int Error_d,Iterm_d,Pterm_dTMP,Pterm_d;
int Error_q,Iterm_q,Pterm_q,Pterm_qTMP;
FloatU id,iq;
int ialfa_INT,ibeta_INT;
int Id,Iq;
int qLimit;
int qLimit2,qLimit3;
volatile int Pos_temp,Pos_temp2,Pos_temp3;
volatile	int SPD_Loop_Per,Error_spd,SP_spd,Iterm_spd,Pterm_spd;
//ADC VARIABLES
volatile uint32_t ADC_values[4];
volatile uint32_t ADC34_values[4];
extern volatile int Sin,Cos,VBus,Chip_Temp,IU,IV;

//ENCODER VARIABLES

const float a=32767.0f;
volatile int indexx;
volatile long int interp;
volatile long int XY;
volatile long int t;
volatile int X,Y,A;
volatile uint16_t B,B2,B3;
long int tets;
volatile int octant,octant2;
extern float thetaSum,theta_eSum;
volatile long int thetaI,Turns,Theta_Turns;
volatile float theta,theta2,theta_e,AbsTheta,AbsTheta2;
volatile int Sa,Ca,S,C;
volatile int Sin_,Cos_,SINMAX,SINMIN,COSMAX,COSMIN;
int cos2,sin2;
int ATAN_Table[33] = 
{
58,331,653,976,1298,1617,1934,2247,2555,2860,3159,3453,3742,4025,4301,4572,
4836,5093,5344,5588,5826,6057,6282,6500,6712,6917,7116,7310,7497,7679,7855,8026,8192
};

void Trip(void){
	
	TIM1->CCER &= 0xEAAA;						//Disable OUTPUTS 1-6
	TIM1->CR1  &= 0xFFFE;						//STOP Counter
	TIM1->BDTR &= ~TIM_BDTR_MOE;
	HAL_NVIC_DisableIRQ(DMA1_Channel1_IRQn);
	HAL_NVIC_DisableIRQ(ADC1_2_IRQn);
	HAL_NVIC_DisableIRQ(USART1_IRQn);//USART1_IRQHandler	
	HAL_GPIO_WritePin(SSR_GPIO_Port,SSR_Pin,GPIO_PIN_RESET);
	SSD1306_Clear();	//apaga display
	while (1)
	{
	 TIM1->BDTR &= ~TIM_BDTR_MOE;	//MASTER OUTPUT PWM2
	 
	 
	  //PRINT RPM
	 SSD1306_GotoXY (0,0);
    SSD1306_Puts ("TRIP", &Font_11x18, SSD1306_COLOR_WHITE);
	 // PRINT TRIP CODE
	 SSD1306_GotoXY (55, 0); 
	switch (Status) {
		case 'M': SSD1306_Puts ("MOD OC", &Font_11x18, SSD1306_COLOR_WHITE);
		case 'I': SSD1306_Puts ("OVERC ", &Font_11x18, SSD1306_COLOR_WHITE);
		case 'O': SSD1306_Puts ("ADCERR", &Font_11x18, SSD1306_COLOR_WHITE);
		case 'V': SSD1306_Puts ("VDCUND", &Font_11x18, SSD1306_COLOR_WHITE);
		case 'P': SSD1306_Puts ("PWROFF", &Font_11x18, SSD1306_COLOR_WHITE);
		break;
	}
	SSD1306_GotoXY (5, 25);
	SSD1306_Puts ("RPM", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (5, 40);
	SSD1306_Puts ("TORQUE", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (27, 50);
	SSD1306_Puts ("V", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (60, 48);
	SSD1306_Puts ("o", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (67, 50);
	SSD1306_Puts ("C", &Font_7x10, SSD1306_COLOR_WHITE);
	
	SSD1306_Putc(Status, &Font_11x18, SSD1306_COLOR_WHITE);
	 //PRINT TQ
	SSD1306_GotoXY (60, 40);
   sprintf(buf,"%4.1u",(int)IQM/2);
	SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
	// PRINT POT_TQ
	SSD1306_GotoXY (90, 40); 
	sprintf(buf,"%4.1u",POT_TQ);
	SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
	// PRINT VBUS
	SSD1306_GotoXY (5, 50); 
	sprintf(buf,"%3.1u",VBus);
	SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
   //HAL_Delay(2000);  // 2 secint POT_TQ,POT_RPM;
   SSD1306_UpdateScreen(); //display
	//apaga display

	//HAL_Delay(500);
	}
	
}
int delayy;
void PMSM_FOC(void){

	HAL_GPIO_WritePin(DBG_OUT_GPIO_Port,DBG_OUT_Pin,GPIO_PIN_SET);
	if((delay > delay_1) && (Status <= 'C')) {   
		//delay = 2 = 1ms/ 4000 = 2s
		
		delay++;
		if(delay < (delay_3-1000)) {
			
			if(delay > (delay_1+2)) {
				TIM1->CCER |= 0x555;					//Enable OUTPUTS 1-6
				TIM1->BDTR |= TIM_BDTR_MOE;
			}
			if(delay > delay_2) {

				delay = delay_3;
				
				if ((IUCALIB <= 30.0f) && (IVCALIB <= 30.0f)) {	//Ajusta Offset de corrente ACS712
					IU_OFFSET = IU_OFFSET - ((int) IUCALIB);
					IV_OFFSET = IV_OFFSET - ((int) IVCALIB);
					Status = 'B';
				}
				else {
					//Fault_OFFSET_I = 1;
					Status = 'O';		//OFFSET ERROR 
					//Fault_OFFSET
					Trip();
				}
				
			}
			delayy = delay;
			TIM1->CCR1 = 3600 + (int) (300+delay/20);		//Leg U
			TIM1->CCR2 = 3600 + (int) 0;		//Leg V
			TIM1->CCR3 = 3600 + (int) 0;		//Leg W
			//Enc_Process_INIT();
			//ANG_OFFSET = ANG;
			TIM3->CNT = 0;
			
			
			thetaI = 0;
			Pterm_spd = 0;
			Iterm_spd = 0;
			Iterm_d = 0;
			Iterm_q = 0;
		}
		else {
		if(delay > delay_3) { 
			delay = delay_3;
			TIM1->SR &= 0x7F;						//Clear Fault Break Status
			TIM1->BDTR |= TIM_BDTR_BKE;		//Habilita Fault Break
			TIM1->DIER |= TIM_DIER_BIE;		//Ativa interrupt de Fault Break
		}
			
			
		//Prote��o
		//IU e IV
		//I_PROTECTION = 1000 = 12.08A
		
		
			
		if ((IU > I_PROTECTION) || (IV > I_PROTECTION) || (IU < -I_PROTECTION) || (IV < -I_PROTECTION)) Protect_I_Count++;
		else 	Protect_I_Count = 0;
		
		if (Protect_I_Count > I_PROT_COUNT) {		
			Status = 'I';	//Overcurrent
			//Fault_Overcurrent	= 1;
			Trip();
			return;
		}

		//Calculo da posi��o ANG 0 - 360� / 0 - 65535
		//Pos_elec 4 turns/rotation -> Electrical Position -> 4 Pole Pairs / 0 - 360�/ 0 - 32767
		//Pos_degrees mechanical position / 0 - 360�/ 0 - 32767
		
		//__disable_irq();
		//Enc_Process_Fine();
		//__enable_irq();
		ANG = (TIM3->CNT<<7);
		//Pos_temp3 = (TIM2->CNT - 3999) + Encoder_CNT;
		//cos2 = Cos;
		//sin2 = Sin;
		//Pos_temp2 = Pos_temp3%2000;
		Pos_elec = (65535 - ANG) & 0x3FFF;				//angulo el�trico motor 4 Par de Polos
		Pos_elec = Pos_elec<<1;
		//Pos_degrees = (Pos_temp2*40958/10000) & 0x7FFF;				//angulo mecanico
		Pos_Sin = arm_sin_q15(Pos_elec);
		Pos_Cos = arm_cos_q15(Pos_elec);

		//TIPO DE CONTROLE
		
		#define POSITION 	0
		#define SPEED 		1
		#define CURRENT 	0
		
		#define FIELDW 	0
				
		#if (POSITION) 	//Controle de Posi��o
			SP_pos 	= Sy;//SP_pos + (float)oi3*0.01f;
		#elif (CURRENT) 	//Controle de corrente
			SP_q		=(((float)POT_RPM/20) + SP_q*15)/16;
		#elif (SPEED) 	//Controle de RPM/Corrente
 				SP_spd	= (POT_RPM + SP_spd*15)/16;
			
		#endif
		//Speed Loop
		{

			SPD_Loop_Per++;
			if (SPD_Loop_Per >= 4) {
				delayTQ = delayTQ + 0.2f;												//Soft start do torque
				if (delayTQ > POT_TQ) delayTQ = POT_TQ;
				
				Error_spd = SP_spd - RPM;//SPEED2.f;	//1429= MaxRPM/MaxPterm_spd
				qLimit = 250;
				Iterm_spd = Iterm_spd + Error_spd*CSpd.I/32767;					//+Iterm2_d;
				if (Iterm_spd > qLimit) Iterm_spd = qLimit;					//anti-windup
				else if (Iterm_spd < -qLimit) Iterm_spd = -qLimit;
				//Pterm_dTMP = Error_d*CCur.P.f;
				Pterm_spd = Error_spd*CSpd.P/32767 + Iterm_spd;				//Resultante Controle Corrente D


				if (Pterm_spd > delayTQ) Pterm_spd = delayTQ;					//Limitador Sa�da com limitador softstart
				else if (Pterm_spd < -delayTQ) Pterm_spd = -delayTQ;
				#if (SPEED == 1) 	//Controle de RPM/Corrente
					SP_q= Pterm_spd;	//Sa�da Speed Loop
				#endif

				SPD_Loop_Per = 0;
			}
			
		}		
		//*******   A B C to Alpha Beta
		
		//ialfa = SQRT23*Iam - SQRT23*Ibm/2 - SQRT23*Icm/2; ia + ib + ic = 0 / ic = -ia -ib
		//ibeta = 0 + SQRT2_2*Ibm - SQRT2_2*Icm;

		
		ialfa_INT = IU;
		ibeta_INT = SQRT13_INT*IU/32767 + SQRT23_INT*IV/32767;
		
		//Alpha Beta to DQ
		
		Id = (Pos_Cos*ialfa_INT/32767) + (Pos_Sin*ibeta_INT/32767);
		Iq = -(Pos_Sin*ialfa_INT/32767) + (Pos_Cos*ibeta_INT/32767);

		IQM = Iq/82.74747f;
		//id.f =  (Pos_Cos*ialfa_INT/32767) + (Pos_Sin*ibeta_INT/32767);
		//iq.f = -(Pos_Sin*ialfa_INT/32767) + (Pos_Cos*ibeta_INT/32767);
		
		//*******   Current control 'D' part
		{
		#if (FIELDW==1) 	//Controle de RPM/Corrente
			SP_d = POTD	;		//Field Weakening
			//SP_d = SP_d;
		#else
			SP_d = 0;
		#endif

		Error_d=SP_d-Id;
		qLimit = 1500;
		Iterm_d = Iterm_d + Error_d*CCur.I/32767;					//+Iterm2_d;
		if (Iterm_d > qLimit) Iterm_d = qLimit;					//anti-windup
		else if (Iterm_d < -qLimit) Iterm_d = -qLimit;
		//Pterm_dTMP = Error_d*CCur.P.f;
		Pterm_d = Error_d*CCur.P/32767 + Iterm_d;				//Resultante Controle Corrente D

		if (Pterm_d > qLimit) Pterm_d = qLimit;					//Limitador Sa�da
		else if (Pterm_d < -qLimit) Pterm_d = -qLimit;
		}	
				
		//*******   Current control 'Q' part
		{
		arm_sqrt_q31(10240000 - (Pterm_d*Pterm_d),&qLimit);				//Limitador geom�trico do 'q' baseado no Pterm_D
		
		qLimit = qLimit/46341;		//SQRT function adequa��o
		if (qLimit > 3200) qLimit = 3200;

		Error_q=SP_q-Iq;
			
		Iterm_q = Iterm_q + Error_q*CCur.I/32767;

		if (Iterm_q > qLimit) Iterm_q = qLimit;					//anti-windup
		else if (Iterm_q < -(qLimit)) Iterm_q = -qLimit;
		//Pterm_qTMP = Error_q*CCur.P.f;
		Pterm_q = Error_q*CCur.P/32767 + Iterm_q;				//Resultante Controle Corrente Q

		if (Pterm_q > qLimit) Pterm_q = qLimit;					//Limitador Sa�da
		else if (Pterm_q < -qLimit) Pterm_q = -qLimit;		
		
		//Q positivo Movimento ANTIHORARIO, Angula��o aumenta (Positiva) +

		}
		//Pterm_d = 0;
		//Pterm_q = Q_;
		ialfa_INT = (Pos_Cos*Pterm_d/32767) - (Pos_Sin*Pterm_q/32767);		
		ibeta_INT = (Pos_Sin*Pterm_d/32767) + (Pos_Cos*Pterm_q/32767);	
		
		Va = ialfa_INT;
		Vb = -ialfa_INT/2 + SQRT32_INT*ibeta_INT/32767;
		Vc = -ialfa_INT/2 - SQRT32_INT*ibeta_INT/32767;
		
		Vm2 = (MAX(Va,Vb,Vc) + MIN(Va,Vb,Vc))/2;
		Va2 = -Vm2 + Va;
		Vb2 = -Vm2 + Vb;
		Vc2 = -Vm2 + Vc;
		
		Status = 'C';	//Control Loop working
	
		if (VaMAX < abs(Vb2)) {
			VaMAX = abs(Vb2);
		}
		//ADC_SYNC();
		
		TIM1->CCR1 = 3600 + (int) Va2;			//Leg U
		TIM1->CCR2 = 3600 + (int) Vb2;			//Leg V
		TIM1->CCR3 = 3600 + (int) Vc2;			//Leg W
		
		//TIM8->CCR5 = 3600 + ADC_ENC_SYNC + 0;
		//TIM8->CCR6 = 3600 + ADC_ENC_SYNC + 400;
				
	}
		
	}
		else {
		IUCALIB = (IU + IUCALIB*1000)/1001;
		IVCALIB = (IV + IVCALIB*1000)/1001;	
		delay++;
		}
		HAL_GPIO_WritePin(DBG_OUT_GPIO_Port,DBG_OUT_Pin,GPIO_PIN_RESET);
}


int MAX(int v1,int v2,int v3) {
	if ((v1 >= v2) && (v1 >= v3)) {
		return v1;
	}
	else if ((v2 > v1) && (v2 > v3)) {
		return v2;
	}
	else {
		return v3;
	}
}
int MIN(int v1,int v2,int v3) {
	if ((v1 <= v2) && (v1 <= v3)) {
		return v1;
	}
	else if ((v2 < v1) && (v2 < v3)) {
		return v2;
	}
	else {
		return v3;
	}
}
volatile int zera;
int OUT_FRAC,MULT1,MULT2,SUM1,SUM2,INT_A,INT_B,OUT = 0;
int OUT_INT,ANG3;
//ENCODER LOOP TRACKING

volatile float SinF,CosF,Square,OUT_DEGREE;
int SGain = 1320,CGain = 1320;
int Fs = 20000.0f;
int K1=2500;
int K2=0.4*32767;
const float RAD_TO_DEGREE=57.2957795f;
int K_SCALE = 1;
int ERRO;

void Table_char_PC(void){

		TABLETXPC[0] = '/';
		TABLETXPC[1] = '*';
		TABLETXPC[2] = Status;				//STATUS
		TABLETXPC[3] = ',';
		
		sprintf(buf2,"%5f",(float)RPM/2);	//RPM
		TABLETXPC[4] = buf2[0];
		TABLETXPC[5] = buf2[1];
		TABLETXPC[6] = buf2[2];
		TABLETXPC[7] = buf2[3];
		TABLETXPC[8] = buf2[4];
		TABLETXPC[9] = buf2[5];
		TABLETXPC[10] = buf2[6];
		TABLETXPC[11] = ',';
	
		sprintf(buf2,"%5f",(float)POT_RPM/2);	//RPM SP
		TABLETXPC[12] = buf2[0];
		TABLETXPC[13] = buf2[1];
		TABLETXPC[14] = buf2[2];
		TABLETXPC[15] = buf2[3];	
		TABLETXPC[16] = buf2[4];
		TABLETXPC[17] = buf2[5];
		TABLETXPC[18] = buf2[6];
		TABLETXPC[19] = ',';
		
		sprintf(buf2,"%5f",(float)IQM);		//CURRENT
		TABLETXPC[20] = buf2[0];
		TABLETXPC[21] = buf2[1];
		TABLETXPC[22] = buf2[2];
		TABLETXPC[23] = buf2[3];	
		TABLETXPC[24] = buf2[4];
		TABLETXPC[25] = buf2[5];
		TABLETXPC[26] = buf2[6];
		TABLETXPC[27] = ',';
		
		sprintf(buf2,"%5f",(float)POT_TQ/83);		//TQ SP
		TABLETXPC[28] = buf2[0];
		TABLETXPC[29] = buf2[1];
		TABLETXPC[30] = buf2[2];
		TABLETXPC[31] = buf2[3];
		TABLETXPC[32] = buf2[4];
		TABLETXPC[33] = buf2[5];
		TABLETXPC[34] = buf2[6];
		
		TABLETXPC[35] = '*';	
		TABLETXPC[36] = '/';
	}



void INIT_ALL(void) {
	
	//SysTick_Config(1440); ////144000 -> 2ms
	//DMA INIT
	
	//ADC 1 e 2 DMA	SINCOS e CHIPTEMP

	//DMA1_Channel1->CNDTR = 2;															//Tamanho do dado
	//DMA1_Channel1->CPAR = (uint32_t)&ADC12_COMMON->CDR;
	//DMA1_Channel1->CMAR = (uint32_t)&ADC_values;
	
	
	//ADC 3 e 4 DMA	VBUS, CHIP_TEMP,  IU e IV

	DMA2_Channel5->CNDTR = 2;															//Tamanho do dado
	DMA2_Channel5->CPAR = (uint32_t)&ADC34_COMMON->CDR;
	DMA2_Channel5->CMAR = (uint32_t)&ADC34_values;
	
	
	//ADC INIT
	HAL_ADCEx_Calibration_Start(&hadc1,ADC_SINGLE_ENDED);
	HAL_ADCEx_Calibration_Start(&hadc2,ADC_SINGLE_ENDED);
	HAL_ADCEx_Calibration_Start(&hadc3,ADC_SINGLE_ENDED);
	HAL_ADCEx_Calibration_Start(&hadc4,ADC_SINGLE_ENDED);

	//DAC
	//DAC1->DHR12R1 = 2048;
  // DAC1->CR |= DAC_CR_EN1;
	
	//ADC 1 A3 POT
	//ADC 2 A5 POT2
	//ADC 3 B1 I_V, 	B13 CHIP_TEMP
	//ADC 4 B12 VBUS, B14 I_U
	
	ADC1->CR = ADC_CR_ADEN;
	ADC2->CR = ADC_CR_ADEN;
	
	ADC3->CR = ADC_CR_ADEN;
	ADC4->CR = ADC_CR_ADEN;
	//ADC1->CFGR |= ADC_CFGR_DMAEN;
	//ADC2->CFGR |= ADC_CFGR_DMAEN;
	ADC1_2_COMMON->CCR |= ADC12_CCR_DMACFG;
	ADC1_2_COMMON->CCR &= 0xFFFFF0;
	ADC1_2_COMMON->CCR |= ADC12_CCR_MULTI_0;//STCUBEMX CORRECTION
	
	ADC1->CR |= ADC_CR_JADSTART;
	ADC1->IER |= ADC_IER_EOSIE | ADC_IER_JEOSIE;
	
	ADC2->CR |= ADC_CR_JADSTART;
	
	ADC3_4_COMMON->CCR |= ADC34_CCR_DMACFG;
	ADC3->CR |= ADC_CR_ADSTART;
	ADC3->IER |= ADC_IER_EOSIE;
	//ADC1->CR2 |= ADC_CR2_DMA;
	//ADC2->CR2 |= ADC_CR2_DMA;
	
	//ADC1->CR2 |= ADC_CR2_ADON | ADC_CR2_EXTTRIG;
	//ADC2->CR2 |= ADC_CR2_ADON | ADC_CR2_EXTTRIG;	
	
	// TIMER 1 PWM
	TIM1->CCER |= (TIM_CCER_CC1E | TIM_CCER_CC1NE | TIM_CCER_CC2E | TIM_CCER_CC2NE | TIM_CCER_CC3E | TIM_CCER_CC3NE);
	//TIM1->DIER |= TIM_DIER_BIE;	//BREAK INTERRUPT
	TIM1->BDTR &= !TIM_BDTR_BKE;	//DESABILITA BREAK, HABILITADO DEPOIS
	TIM1->BDTR |= TIM_BDTR_MOE | 0x00D8;	//MASTER OUTPUT PWM & DEADTIME 0xD8(3.1us = 450@144MHz)
	TIM1->BDTR |= 0xF<<TIM_BDTR_BKF_Pos;
	//TIM1->ARR = 9000;//
	TIM1->CR1 |= TIM_CR1_CEN;		//TIMER EN
	
	TIM3->CCMR1 |= TIM_CCMR1_IC1F_0 | TIM_CCMR1_IC1F_1 | TIM_CCMR1_IC1F_2 | TIM_CCMR1_IC1F_3;	//Encoder Input Filter
	TIM3->CCMR1 |= TIM_CCMR1_IC2F_0 | TIM_CCMR1_IC2F_1 | TIM_CCMR1_IC2F_2 | TIM_CCMR1_IC2F_3; //Encoder Input Filter
	TIM3->CR1 |= TIM_CR1_CEN;		//TIMER ENCODER DIGITAL INPUT ENABLE
	
	//TIMER 8 ENCODER ADC1 e 2 Injected Samples
	//TIM6->ARR = 0x0650;		//40kHz
	TIM8->CR1 |= TIM_CR1_CEN;		//TIMER EN
	

	//TIM2->ARR = 72000000; //1 second
	//DMA1_Channel1->CCR |= DMA_CCR_EN;
	DMA2_Channel5->CCR |= DMA_CCR_EN;
	
	IU_OFFSET = 2045;
	IV_OFFSET = 2035;
	//Status = '0';	//Initial State
	
	CCur.P = 0.072f * 32767;		//1.22		
	CCur.I = 0.30f * 32767;		//0.45		menor = mais lento
	
	CSpd.P = 0.2621f * 32767;			//1.62   0.162
	CSpd.I = 0.0030f * 32767;		//0.022		0

	
	//COMP1->CSR |= COMP_CSR_COMPxEN;
	//COMP2->CSR |= COMP_CSR_COMPxEN;
	
	/*
	//TIMER 2 - RPM TIMER
	TIM2->CR1 |= TIM_CR1_CEN;	
	EXTI->IMR |= EXTI_IMR_IM21 | EXTI_IMR_IM22;
	EXTI->RTSR |= EXTI_RTSR_RT21 | EXTI_RTSR_RT22;
	EXTI->FTSR |= EXTI_FTSR_FT21 | EXTI_FTSR_FT22;
	*/
	
	//CSpd.D.f = 0.05f;			//0.05		//0.5
	
	//CPosition.P.f = 0.01f;
	//CPosition.P2.f = 0.03f;
	//CPosition.I.f = 0.0002f;		//I when Locked
	//CPosition.D.f = 0.2f;			//P2 when locked
	//SP_d = 0;
	//SPI1->CR1 |= SPI_CR1_SPE;
	//SPI1->CR2 |= SPI_CR2_RXNEIE;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_ADC3_Init();
  MX_ADC4_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
	SysTick_Config(72000);//72000= 1msec
	HAL_GPIO_WritePin(SSR_GPIO_Port,SSR_Pin,GPIO_PIN_SET);
	//HAL_Delay(200);

	INIT_ALL();
	SSD1306_Init();  // initialise

	/// Display Print
   SSD1306_GotoXY (0,0);
   //SSD1306_Puts ("DRL MASTER", &Font_11x18, 1);
	//SSD1306_GotoXY (5, 25);
	//SSD1306_Puts ("RPM", &Font_7x10, 1);
	SSD1306_GotoXY (5, 25);
	SSD1306_Puts ("TORQUE", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (28, 50);
	SSD1306_Puts ("V", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (100, 48);
	SSD1306_Puts ("o", &Font_7x10, SSD1306_COLOR_WHITE);
	SSD1306_GotoXY (107, 50);
	SSD1306_Puts ("C", &Font_7x10, SSD1306_COLOR_WHITE);
    //HAL_Delay(2000);  // 2 sec
   SSD1306_UpdateScreen(); //display
	HAL_Delay(50);
  //Enc_Process_INIT();

	//HAL_GPIO_WritePin(relay2_GPIO_Port,relay2_Pin,1);

	//while (VBus < 100) {
	//}
	HAL_GPIO_WritePin(RLY_IRUSH_GPIO_Port,RLY_IRUSH_Pin,GPIO_PIN_SET);
	HAL_Delay(150);
	Status = 'A';	//Initial State + Relayok
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  
	  HAL_Delay(50);
	  
	  //SERIAL MONITOR
	 // Table_char_PC();
	 // HAL_UART_Transmit(&huart3,TABLETXPC,37,100);
	  
	  
	  //PRINT RPM
	SSD1306_GotoXY (0,0);
	if (RPM > 0) {
    sprintf(buf,"+%4.1u",abs(RPM/2));
	 SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	}
	else if (RPM == 0) {
    sprintf(buf,"%4.1u",0);
	 SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	}
	else {
    sprintf(buf,"-%4.1u",abs(RPM/2));
	 SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	}
	 // PRINT POT_RPM
	 SSD1306_GotoXY (60, 0); 
	 if (POT_RPM > 0) {
		sprintf(buf,"+%4.1u",abs(POT_RPM/2));
		SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	 }
	 else if (POT_RPM == 0) {
		sprintf(buf,"%4.1u",abs(POT_RPM/2));
		SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	 }
	 else {
		sprintf(buf,"-%4.1u",abs(POT_RPM/2));
		SSD1306_Puts (buf, &Font_11x18, SSD1306_COLOR_WHITE);
	 }
	  //PRINT TQ
	 SSD1306_GotoXY (60, 25);
	 tqtemp = (float)IQM;

	float tmpVal = (tqtemp < 0) ? -tqtemp : tqtemp;

	int tmpInt1 = tmpVal;                  // Get the integer (678).
	float tmpFrac = tmpVal - tmpInt1;      // Get fraction (0.0123).
	int tmpInt2 = trunc(tmpFrac * 10);  // Turn into integer (123).

// Print as parts, note that you need 0-padding for fractional bit.

	sprintf (buf, "%d.%0d", tmpInt1, tmpInt2);
	 SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
	 // PRINT POT_TQ
	 SSD1306_GotoXY (100, 25); 
		
	 tqtemp = (float)POT_TQ/83;

	tmpVal = (tqtemp < 0) ? -tqtemp : tqtemp;

	tmpInt1 = tmpVal;                  // Get the integer (678).
	tmpFrac = tmpVal - tmpInt1;      // Get fraction (0.0123).
	tmpInt2 = trunc(tmpFrac * 10);  // Turn into integer (123).

// Print as parts, note that you need 0-padding for fractional bit.

	sprintf (buf, "%d.%0d", tmpInt1, tmpInt2);

	 //sprintf(buf,"%d.%d",POT_TQ/83,(POT_TQ/83)%10);
	 SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
	 // PRINT VBUS
	 SSD1306_GotoXY (5, 50); 
	 sprintf(buf,"%3.1u",VBus);
	 SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
	 
	 // PRINT IGBT Module Temperature
	 SSD1306_GotoXY (80, 50); 
	 sprintf(buf,"%3.1u",(int)Chiptemp);
	 SSD1306_Puts (buf, &Font_7x10, SSD1306_COLOR_WHITE);
    //HAL_Delay(2000);  // 2 secint POT_TQ,POT_RPM;
    SSD1306_UpdateScreen(); //display
	  
	 //apaga display
	  SSD1306_GotoXY (60, 25);
	  SSD1306_Puts ("    ", &Font_7x10, SSD1306_COLOR_WHITE);
	  SSD1306_GotoXY (00, 00);
	  SSD1306_Puts ("             ", &Font_11x18, SSD1306_COLOR_WHITE);
	  SSD1306_GotoXY (90, 25); 
	  //SSD1306_Puts ("      ", &Font_7x10, 1);
	  //HAL_GPIO_WritePin(SSR_GPIO_Port,SSR_Pin,SSR_RELAY);
	  
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART3|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_TIM1|RCC_PERIPHCLK_ADC12
                              |RCC_PERIPHCLK_ADC34;
  PeriphClkInit.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;
  PeriphClkInit.Adc12ClockSelection = RCC_ADC12PLLCLK_DIV1;
  PeriphClkInit.Adc34ClockSelection = RCC_ADC34PLLCLK_DIV1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.Tim1ClockSelection = RCC_TIM1CLK_PLLCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_InjectionConfTypeDef sConfigInjected = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_DUALMODE_REGSIMULT_ALTERTRIG;
  multimode.DMAAccessMode = ADC_DMAACCESSMODE_12_10_BITS;
  multimode.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Injected Channel
  */
  sConfigInjected.InjectedChannel = ADC_CHANNEL_4;
  sConfigInjected.InjectedRank = ADC_INJECTED_RANK_1;
  sConfigInjected.InjectedSingleDiff = ADC_SINGLE_ENDED;
  sConfigInjected.InjectedNbrOfConversion = 1;
  sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_19CYCLES_5;
  sConfigInjected.ExternalTrigInjecConvEdge = ADC_EXTERNALTRIGINJECCONV_EDGE_RISINGFALLING;
  sConfigInjected.ExternalTrigInjecConv = ADC_EXTERNALTRIGINJECCONV_T1_TRGO;
  sConfigInjected.AutoInjectedConv = DISABLE;
  sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
  sConfigInjected.QueueInjectedContext = DISABLE;
  sConfigInjected.InjectedOffset = 0;
  sConfigInjected.InjectedOffsetNumber = ADC_OFFSET_NONE;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc1, &sConfigInjected) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_InjectionConfTypeDef sConfigInjected = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Injected Channel
  */
  sConfigInjected.InjectedChannel = ADC_CHANNEL_2;
  sConfigInjected.InjectedRank = ADC_INJECTED_RANK_1;
  sConfigInjected.InjectedSingleDiff = ADC_SINGLE_ENDED;
  sConfigInjected.InjectedNbrOfConversion = 1;
  sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_19CYCLES_5;
  sConfigInjected.AutoInjectedConv = DISABLE;
  sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
  sConfigInjected.QueueInjectedContext = DISABLE;
  sConfigInjected.InjectedOffset = 0;
  sConfigInjected.InjectedOffsetNumber = ADC_OFFSET_NONE;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &sConfigInjected) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief ADC3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC3_Init(void)
{

  /* USER CODE BEGIN ADC3_Init 0 */

  /* USER CODE END ADC3_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC3_Init 1 */

  /* USER CODE END ADC3_Init 1 */

  /** Common config
  */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc3.Init.ContinuousConvMode = DISABLE;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc3.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_TRGO;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.NbrOfConversion = 2;
  hadc3.Init.DMAContinuousRequests = DISABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_DUALMODE_REGSIMULT;
  multimode.DMAAccessMode = ADC_DMAACCESSMODE_12_10_BITS;
  multimode.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc3, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_19CYCLES_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC3_Init 2 */

  /* USER CODE END ADC3_Init 2 */

}

/**
  * @brief ADC4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC4_Init(void)
{

  /* USER CODE BEGIN ADC4_Init 0 */

  /* USER CODE END ADC4_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC4_Init 1 */

  /* USER CODE END ADC4_Init 1 */

  /** Common config
  */
  hadc4.Instance = ADC4;
  hadc4.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc4.Init.Resolution = ADC_RESOLUTION_12B;
  hadc4.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc4.Init.ContinuousConvMode = DISABLE;
  hadc4.Init.DiscontinuousConvMode = DISABLE;
  hadc4.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc4.Init.NbrOfConversion = 2;
  hadc4.Init.DMAContinuousRequests = DISABLE;
  hadc4.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  hadc4.Init.LowPowerAutoWait = DISABLE;
  hadc4.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_19CYCLES_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC4_Init 2 */

  /* USER CODE END ADC4_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0000020B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED1;
  htim1.Init.Period = 7200;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_ENABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 511;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 57600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA2_Channel5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Channel5_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA2_Channel5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SSR_GPIO_Port, SSR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, DBG_OUT_Pin|RLY_2_Pin|RLY_IRUSH_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : INP1_Pin FW_RW_Pin */
  GPIO_InitStruct.Pin = INP1_Pin|FW_RW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : SSR_Pin */
  GPIO_InitStruct.Pin = SSR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SSR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DM_Pin DMA1_Pin DMA2_Pin DMA4_Pin */
  GPIO_InitStruct.Pin = DM_Pin|DMA1_Pin|DMA2_Pin|DMA4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DMB0_Pin DMB2_Pin PB4 PB5 */
  GPIO_InitStruct.Pin = DMB0_Pin|DMB2_Pin|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : DBG_OUT_Pin */
  GPIO_InitStruct.Pin = DBG_OUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DBG_OUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RLY_2_Pin RLY_IRUSH_Pin */
  GPIO_InitStruct.Pin = RLY_2_Pin|RLY_IRUSH_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
