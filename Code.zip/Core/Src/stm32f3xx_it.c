/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f3xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//long int TIM_RPM;
//float RPMf,RPMf2;
//extern float RPMMM;
extern float I_NOMINAL;
extern volatile char Status;
char Dir;
double CosMean,SinMean;
extern volatile uint32_t ADC_values[4];
extern volatile uint32_t ADC34_values[4];
volatile int Sin,Cos,VBus,VBusRAW,IU,IV,ChiptempRAW;
volatile float Chiptemp;
extern void PMSM_FOC(void);
extern void Enc_Process_Coarse(void);
extern int thetaI,Turns;
int ANG2,ANG1,RPM,RPM_;
volatile int CO1,CO2,CO1a,CO2a,ThetaI_P,PR12;
extern uint16_t ANG;
int idxtable;
int TABLEANG1[100],TABLEANG2[100],TABLEANG3[100];
int CurrentLoopPer,IV_INT,IU_INT;
int IU_OFFSET,IV_OFFSET;
float IUF,IVF;
int POT_TQ,POT_RPM;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
/*
void COMP1_2_3_IRQHandler(void)
  PR12 = (EXTI->PR>>21) & (0x03);	//Pending Register
  if(PR12 == 1)	//COMP1 
  {
	CO1 = (COMP1->CSR >> 16) & (COMP_CSR_COMPxOUT>>16);
	CO2 = (COMP2->CSR >> 16) & (COMP_CSR_COMPxOUT>>16);
	if (CO1 == 0) {
		if (CO2 == 0) ThetaI_P++;
		else ThetaI_P--;
	}
	else {
		if (CO2 == 0) ThetaI_P--;
		else ThetaI_P++;
	}
  }
  else if(PR12 == 2)							//or COMP2
  {
	CO1 = (COMP1->CSR >> 16) & (COMP_CSR_COMPxOUT>>16);
	CO2 = (COMP2->CSR >> 16) & (COMP_CSR_COMPxOUT>>16);
	if (CO2 == 0) {
		if (CO1 == 0) ThetaI_P--;
		else ThetaI_P++;
	}
	else {
		if (CO1 == 0) ThetaI_P++;
		else ThetaI_P--;
	}
  }
  }
int ADC_SYNC() {

const int C1 = 1400;
const int C2 = 0.3*3600;
const int C3 = 0.45*3600;

arm_sqrt_q31((Va2*Va2)+(Vb2*Vb2)+(Vc2*Vc2),&RMS);
RMS = RMS/46341;
	
if (RMS < C1) { ADC_ENC_SYNC = C3; }
else {
	if ((Va2 >= Vb2) & (Va2 >= Vc2)) {
		//MAX = Va2;
		if(Vb2 > Vc2) 	{	if ((Va2 - Vb2) < C2) ADC_ENC_SYNC = (Vb2+Vc2)/2;
						else ADC_ENC_SYNC = (Va2+Vb2)/2;
		}
		else {		
			if ((Va2 - Vc2) < C2) ADC_ENC_SYNC =  (Vb2+Vc2)/2;
			else ADC_ENC_SYNC = (Va2+Vc2)/2;
		}
	}
	else if ((Vb2 > Va2) & (Vb2 > Vc2)) {
		//MAX = Vb2;
		if(Va2 > Vc2)  	{	if ((Vb2 - Va2) < C2) ADC_ENC_SYNC =  (Va2+Vc2)/2;
						else ADC_ENC_SYNC = (Vb2+Va2)/2;
		}
		else {
			if ((Vb2 - Vc2) < C2) ADC_ENC_SYNC =  (Va2+Vc2)/2;
			else ADC_ENC_SYNC = (Vb2+Vc2)/2;
		}
	}
	else 	{
		//MAX = Vc2;
		if(Va2 > Vb2) 	{	if ((Vc2 - Va2) < C2) ADC_ENC_SYNC =  (Vb2+Va2)/2;
						else ADC_ENC_SYNC = (Vc2+Va2)/2;
		}
		else {
			if ((Vc2 - Vb2) < C2) ADC_ENC_SYNC =  (Vb2+Va2)/2;
			else ADC_ENC_SYNC = (Vc2+Vb2)/2;
		}
	}
}
}
void Atan_interp(void) {
	indexx = A/1024;//(A>>10 );
	A = (A - (indexx<<10));
	interp = ATAN_Table[indexx+1] - ATAN_Table[indexx];
	interp = interp*A;
	A = interp/1024;
	A = A + ATAN_Table[indexx];
}
void Enc_Process_Coarse(void)
{
//Octant Coarse angle calculation
	
if (Sin >= 0) 
{
	S = 1;
	if (Cos >= 0) {
		C = 1;
		//if (Sin < Cos) 	octant = 0;
		//else 					octant = 1;

	}
	else { 				//Sin>0 e Cos <0 
		C = 0;
		//if (Sin <= -Cos) 	octant = 3;
		//else 					octant = 2;
	}
}
else {
	S = 0;
	if (Cos >= 0) {	//Sin<0 e Cos>0
		C = 1;
		//if (-Sin <= Cos) 	octant = 7;
		//else 					octant = 6;
	}
	else { 				//Sin<0 e Cos<00
		C = 0;
		//if (-Sin < -Cos) 	octant = 4;
		//else 					octant = 5;
	}	
}
	//A = Octant separated angle
	//B = Entire period angle
	//S/C = Sin/Cos signal	Sa/Ca= Sin/Cos signal before

	//Quadrature Counter/ Course angle calculation 512 counts/mechanical turn
	if (S != Sa) {//& (C == Ca)) {
		if (S != C) 	thetaI--;
		else 				thetaI++;
	}
	if (C != Ca) {//& (S == Sa)) {
		if (S == C) 	thetaI--;	
		else 				thetaI++;	
	}
	Sa = S;
	Ca = C;	

	
		//ENC PROCESS FINE
	
	
		if(thetaI > 511) { 
		thetaI = thetaI - 512;
		Turns++;
	}
	else if (thetaI < -511) {
		thetaI = thetaI + 512;
		Turns--;
	}
	//Turns = Mechanical turns
	
	//A = (A/512) + 64;
	//thetaI = abs(thetaI)%512;
	//thetaI = 0;
	//A = -32760;
	ANG = (thetaI<<7);// + (B>>9);
}

void Enc_Process_INIT(void)
{
	if (Sin >= 0) 
	{
		S = 1;
		if (Cos >= 0) 
		{
			C = 1;
			if (Sin < Cos) 	octant = 0;	
			else 					octant = 0;	
		}
		else 
		{
			C = 0;
			if (Sin <= -Cos) 	octant = 1;
			else 					octant = 1;
		}
	}
	else 
	{
		S = 0;
		if (Cos >= 0) //Sin<0 e Cos>0
		{
			C = 1;
			if (-Sin <= Cos)	octant = 3;
			else 					octant = 3;
		}
		else //Sin<0 e Cos<00
		{
			C = 0;
			if (-Sin < -Cos) 	octant = 2;
			else 					octant = 2;
		}	
	}
	Sa = S;
	Ca = C;
	thetaI = octant;
	Theta_Turns = octant;
	Turns = 0;
}
void Enc_Process_Fine(void)
{
	
//Octant and Fine angle calculation
	switch (octant) {
		case 0:
			X = Sin;
			Y = Cos;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = A + 0;
		break;
		case 1:
			X = Cos;
			Y = Sin;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = 16383 - A;
		break;
		case 3:
			X = Sin;
			Y = -Cos;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = 32767 - A;
		break;
		case 2:
			X = -Cos;
			Y = Sin;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = A + 16383;
		break;
		case 7:
			X = -Sin;
			Y = Cos;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = 32767 + 32767 - A;
		break;
		case 6:
			X = Cos;
			Y = -Sin;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
  			B = 32767 + 16383 + A;
		break;
		case 4:
			X = -Sin;
			Y = -Cos;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
			B = 32767 + A;
		break;
		case 5:
			X = -Cos;
			Y = -Sin;
			XY = 32767*X;
			XY = XY/Y;
			A = XY;
			Atan_interp();
  			B = 32767 + 16383 - A;
		break;
			
	}	

	//thetaI = Quadrature Counter 4 counts/period -> (128(SKS36) * 4) = 512 counts/mechanical turn
	if(thetaI > 511) { 
		thetaI = thetaI - 512;
		Turns++;
	}
	else if (thetaI < -511) {
		thetaI = thetaI + 512;
		Turns--;
	}
	//Turns = Mechanical turns
	
	A = (A/512) + 64;
	//thetaI = abs(thetaI)%512;
	//thetaI = 0;
	//A = -32760;
	ANG = (thetaI<<7);// + (B>>9);
	
	//ANG = (TIM3->CNT<<7) + (B>>9);
	/*
	tets = (thetaI)/4;
	B2 = ((B>>9) + tets*128)%16384;
	//B2 = ((B>>9) + tets*128 + octant*8)%16384;// /128    - B3;	//B3 = Zeramento do Angulo 
	B3 = (B2*4)%16384;
	theta2 = (float) B3;
	theta_e= theta2/(2607.59458f);		//Angula��o el�trica de 0 a 2pi ; 1/4 de volta mecanica
	theta2 = (float) B2;
	theta = theta2;///(2607.59458f);			//Angula��o mecanica de 0 a 2pi ; 1 volta mecanica
	
	//Calculo theta absoluto
		long int T,T2,temps;
		tets = (Theta_Turns);///4;
	
		if (tets < 0) {
			tets = tets + 1;
			tets = tets/4;
			T = (tets*128);
			theta2 = (float) (128-(B>>9))- octant*8;
			AbsTheta2 = (float) T - theta2;//			FALHA EM angulos negativos (B>>9) +Theta_Turns
		}
		else {
			tets = tets/4;
			
			T = (tets*128);
			theta2 = (float) ((B>>9)+ octant*8);
			AbsTheta2 = (float) T + theta2;//			FALHA EM angulos negativos (B>>9) +Theta_Turns
		}

		

		//AbsTheta2 = AbsTheta2 + ((float) T2/(45.511110f));
		//theta = ((float) thetaI)/4 + theta/128;
		//DAC2->DHR12R1 = B2/4;//2048 + (int)id
		//theta = 2.8125f*theta;
		//theta = theta/360.0f;
		//AbsTheta
	*/
 	//octant2 = octant;

		/*if (Sin > SINMAX) SINMAX = Sin;
		if (Sin < SINMIN) SINMIN = Sin;
		if (Cos > COSMAX) COSMAX = Cos;
		if (Cos < COSMIN) COSMIN = Cos;
}
void ENC_Tracking_Process(){


	//RE_->Sin = (((float)RE_->SinI) + (RE_->Sin*7))/8;			//Media m�vel
	//RE_->Cos = (((float)RE_->CosI) + (RE_->Cos*7))/8;
	
	SinF = (float)Sin;			
	CosF = (float)Cos;
	

	
	//RESOLVER AQUISITION TEST 0.65 < RE_->Square < 1.35
	/*
	Square = SinF/SGain * SinF/SGain;
	Square += CosF/CGain * CosF/CGain;
	
	if ((Square < 0.9f) | (Square > 1.1f) ) {
		ERRO = 1;
	}
	else {
		ERRO = 0;
	}
	
	if (zera == 1) {
		zera = 0;
		SinF = 0;
		CosF = 0;
		MULT1 = 0;
		MULT2 = 0;
		SUM1 = 0;
		SUM2 = 0;
		INT_A = 0;
		INT_B = 0;

	}	
	//q15_t arm_sin_q15	(	q15_t 	x	)	

	//The Q15 input value is in the range [0 +0.9999] and is mapped to a radian value in the range 
	//INPUT RANGE [0 ... 2*PI) 0 32767.
	//OUTPUT RANGE [-1 ... 1] -32767 to 32767
	
	MULT1 = Sin*24;// + (32767/2);		
	MULT2 = Cos*24;// + (32767/2);
	

	
	MULT1 = (MULT1 * arm_cos_q15(OUT))/32767;//MULT1 * (2*arm_cos_q15(OUT/2 + (32767/2))/(32767));
	MULT2 = (MULT2 * arm_sin_q15(OUT))/32767;

	SUM1 = (MULT1 - MULT2)*K1;
	
	//With Forward Euler Discrete integrator:   y(n) = y(n-1) + T * u(n-1) 

	INT_A = INT_A + SUM1/Fs;		
	
	INT_B = INT_B + INT_A/Fs;
	
	SUM2 = INT_B + INT_A*K2/32767;
	
	SUM2 = SUM2%(32767*128);
	
	//OUT = SUM2;// * K_SCALE;
	
	if (SUM2 >= 0) OUT = SUM2%(32767);
	else OUT = 32767 + SUM2%(32767);	
	
	//OUT = [0 2PI] [0 32767]
	
	OUT_DEGREE = SUM2/(128);

	//OUT_INT = abs((int) OUT_DEGREE);
	if (OUT_DEGREE >= 0) OUT_DEGREE = OUT_DEGREE;
	else OUT_DEGREE = 32767 + OUT_DEGREE;
	ANG3 = ANG/2;
}
*/
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_adc3;
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern ADC_HandleTypeDef hadc3;
extern TIM_HandleTypeDef htim1;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */
	
	//int idxtable;
	//uint16_t TABLEANG[2][100];
	//CALCULO RPM
	//4000RPM
	// one turn = 512 thetai
	//4000RPM 66.66 turns/second = 34133,33 Thetai/sec = 341.33 thetai/SysTickInt
	//idxtable++;
	//if (idxtable > 99) idxtable = 0;
	// one turn = 65535 ANG
	//4000RPM 66.66 turns/second = 4325310 ANG/sec = 4325,310 ANG/SysTickInt	

	ANG1 = (int)ANG;
	RPM_ = (ANG2 - ANG1);
	//TABLEANG3[idxtable] = RPM_;
	//TABLEANG2[idxtable] = ANG2;
	//TABLEANG1[idxtable] = ANG1;
	//if ((thetaI < 0) & (thetaIa < 0)) {
		if(RPM_ > 4340) RPM_ = -65535 + RPM_;
		if(RPM_ < -4340) RPM_ = 65535 + RPM_;
		//else 				RPM = (thetaI-thetaIa);
		//}
	//}
	//else{
		//if((thetaI-thetaIa) < -345) {
			//RPM = 512 + thetaI-thetaIa;
		//}
		//else {
			//RPM = (thetaI-thetaIa);
		//}
	//}
	
	RPM_ = 4000*RPM_/4325;
	RPM = (RPM_ + RPM*20)/21;
	//RPM = (RPM*117)/10;
  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */
	ANG2 = (int)ANG;
  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F3xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f3xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 channel1 global interrupt.
  */
void DMA1_Channel1_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Channel1_IRQn 0 */

  /* USER CODE END DMA1_Channel1_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_adc1);
  /* USER CODE BEGIN DMA1_Channel1_IRQn 1 */

  /* USER CODE END DMA1_Channel1_IRQn 1 */
}

/**
  * @brief This function handles ADC1 and ADC2 interrupts.
  */
void ADC1_2_IRQHandler(void)
{
  /* USER CODE BEGIN ADC1_2_IRQn 0 */
	
	if ((ADC1->ISR & (ADC_ISR_JEOC | ADC_ISR_JEOS)) != 0) {
		POT_TQ = 4096-(int)(ADC2->JDR1);
		POT_TQ = POT_TQ*I_NOMINAL/4096;
		if (POT_TQ < 15) POT_TQ = 15;
		POT_RPM = (int)(ADC1->JDR1)-2048;
		POT_RPM = POT_RPM*170/100;
		if (abs(POT_RPM) < 100) POT_RPM = 0;
		else {
			if (POT_RPM > 0) POT_RPM = POT_RPM - 100;
			else POT_RPM = POT_RPM + 100;
		}
	}
	else {
		
		//Cos = ((int)(ADC12_COMMON->CDR>>16)-2028);
		//Sin = ((0x0000FFFF & (int)ADC12_COMMON->CDR)-2038);
	}
  
	
	//Enc_Process_Coarse();
	//ENC_Tracking_Process();
	//HAL_GPIO_WritePin(DBG_OUT_GPIO_Port,DBG_OUT_Pin,0);
  /* USER CODE END ADC1_2_IRQn 0 */
  HAL_ADC_IRQHandler(&hadc1);
  HAL_ADC_IRQHandler(&hadc2);
  /* USER CODE BEGIN ADC1_2_IRQn 1 */

  /* USER CODE END ADC1_2_IRQn 1 */
}

/**
  * @brief This function handles TIM1 break and TIM15 interrupts.
  */
void TIM1_BRK_TIM15_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 0 */

  /* USER CODE END TIM1_BRK_TIM15_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 1 */
	Status = 'M';
	Trip();
  /* USER CODE END TIM1_BRK_TIM15_IRQn 1 */
}

/**
  * @brief This function handles ADC3 global interrupt.
  */
void ADC3_IRQHandler(void)
{
  /* USER CODE BEGIN ADC3_IRQn 0 */

		//PHASE CURRENT SAMPLE
	IU_INT = -((ADC34_values[0]>>16)-IU_OFFSET);	//ACS712 Inverted on the PCB
	IV_INT = -((0x0000FFFF & ADC34_values[0])-IV_OFFSET);
	IU = (IU_INT + IU*6)/7;
	IV = (IV_INT + IV*6)/7;
	// 3,3V->4096 = 8.1380208333333333333333333333333e-4 mV/bit resolution
	// ACS712-20A-> 100mV/A ->convers�o de 5 para 3,3V-> 66.6667mV/A
	// 82,74747 count/Ampere ou * 39599/32767 para retornar corrente*100
	//Convers�o somente no float UVF IUF
	IUF = IU/82.74747f;
	IVF = IV/82.74747f;
	
		//BUS VOLTAGE SAMPLE
	VBusRAW = ((int)(ADC34_values[1]>>16)-44);
	VBus = (VBus*19 + VBusRAW/5)/20;
	
	//MODULE CHIP TEMP SAMPLE
	ChiptempRAW = -(0x0000FFFF & ADC34_values[1]);
	ChiptempRAW = ((ChiptempRAW+1625))/5;
	Chiptemp = (Chiptemp*2999 + (float)ChiptempRAW)/3000;
	
  /* USER CODE END ADC3_IRQn 0 */
  HAL_ADC_IRQHandler(&hadc3);
  /* USER CODE BEGIN ADC3_IRQn 1 */
	CurrentLoopPer++;

	if (Status == 0) {
		//if (VBus < 100) {
			CurrentLoopPer = 0;		//Wait for VBus
		//}
	}
	if (Status == 'C') {
		if (VBus < 300) {
			//Status = 'V';
			//Trip();
		}
	}
	if (HAL_GPIO_ReadPin(INP1_GPIO_Port,INP1_Pin) == 1) {
		Status = 'P';
		Trip();
	}
	//RPMMM = RPMf2;
	if (CurrentLoopPer >= 10) {
		
		PMSM_FOC();
		//Periodic();
		CurrentLoopPer = 0;
	}	
	
  /* USER CODE END ADC3_IRQn 1 */
}

/**
  * @brief This function handles DMA2 channel5 global interrupt.
  */
void DMA2_Channel5_IRQHandler(void)
{
  /* USER CODE BEGIN DMA2_Channel5_IRQn 0 */

  /* USER CODE END DMA2_Channel5_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_adc3);
  /* USER CODE BEGIN DMA2_Channel5_IRQn 1 */

  /* USER CODE END DMA2_Channel5_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
